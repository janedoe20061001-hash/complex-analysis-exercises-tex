复变函数与积分变换完整习题解答——Overleaf 快速编译版

使用方法：
1. 将本 ZIP 直接上传到 Overleaf 并新建项目；
2. 编译器选择 XeLaTeX；
3. 主文档选择 main.tex；
4. 点击 Recompile。

说明：
- 正文仍为可编辑的 TeX；
- figures 文件夹中的 PDF 是从原 TikZ 代码预编译得到的矢量图，用于避免免费版编译超时；
- 请勿删除 figures 文件夹，也不要改变其中图形文件名；
- 如需修改某幅图，请在原始完整版 TeX 中修改 TikZ 后重新生成快速编译版。
